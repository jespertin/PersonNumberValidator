Projektet är skapat med Java 17

### Instruktioner

Navigera till projektets src foldern.

Kör "java com.company.Main"





